MemoryPatch::createWithHex("libUE4.so", 0x5708254, "00 00 80 D2 C0 03 5F D6").Modify();
MemoryPatch::createWithHex("libUE4.so", 0x570F714, "00 00 80 D2 C0 03 5F D6").Modify();
MemoryPatch::createWithHex("libUE4.so", 0x606A448, "1F 20 03 D5").Modify();
MemoryPatch::createWithHex("libUE4.so",0x0B0EE390,"00 00 80 D2 C0 03 5F D6").Modify();
MemoryPatch::createWithHex("libanogs.so",0x167114,"00 00 80 D2 C0 03 5F D6").Modify();
MemoryPatch::createWithHex("libanogs.so",0x167504,"00 00 80 D2 C0 03 5F D6").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x14D770,"00 00 80 D2 C0 03 5F D6"); // Case 1
MemoryPatch::createWithHex("libanogs.so", 0x12E540,"00 00 80 D2 C0 03 5F D6"); // Case 2
MemoryPatch::createWithHex("libanogs.so", 0x12E540,"00 00 80 D2 C0 03 5F D6"); // Case 2
MemoryPatch::createWithHex("libanogs.so", 0x3E89E4,"00 00 80 D2 C0 03 5F D6"); // Case 3
MemoryPatch::createWithHex("libanogs.so", 0x3E8ECC,"00 00 80 D2 C0 03 5F D6"); // Case 3
MemoryPatch::createWithHex("libanogs.so", 0x174698,"00 00 80 D2 C0 03 5F D6"); // Case 16 Crash Fix
MemoryPatch::createWithHex("libanogs.so", 0x1749A8,"00 00 80 D2 C0 03 5F D6"); // Case 16 Crash Fix
MemoryPatch::createWithHex("libanogs.so", 0x3DC20C,"00 00 80 D2 C0 03 5F D6"); // 
MemoryPatch::createWithHex("libanogs.so", 0x3DE65C,"00 00 80 D2 C0 03 5F D6"); // 
MemoryPatch::createWithHex("libanogs.so", 0x1672E8,"00 00 80 D2 C0 03 5F D6"); // 
MemoryPatch::createWithHex("libanogs.so", 0x224514,"00 00 80 D2 C0 03 5F D6"); // 
MemoryPatch::createWithHex("libanogs.so", 0x1F3C5C,"00 00 80 D2 C0 03 5F D6"); // 
MemoryPatch::createWithHex("libanogs.so", 0xE1FB8,"00 00 80 D2 C0 03 5F D6"); // 
MemoryPatch::createWithHex("libanogs.so", 0xDF6D4,"00 00 80 D2 C0 03 5F D6"); // 
MemoryPatch::createWithHex("libanogs.so", 0xDFBA0,"00 00 80 D2 C0 03 5F D6"); // 
MemoryPatch::createWithHex("libanogs.so", 0xDFA50,"00 00 80 D2 C0 03 5F D6"); // 
MemoryPatch::createWithHex("libanogs.so", 0xDF6D4,"00 00 80 D2 C0 03 5F D6"); // 